Check out my to do list here : https://quiet-shortbread-5b5949.netlify.app/
